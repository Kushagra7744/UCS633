# TOPSIS Implementation
## Project1 UCS633
### Submitted by Kushagra Thakral 101703301<br>
Implementation of TOPSIS for a simple dataset having 4 columns.<br>
run in CMD:<br>
python3 project1.py file_name.csv 0.25 0.25 0.25 0.25 a-+++b <br>
where a and b can be replaced by any character except shell script keywords.<br>